# Taquito Sapling package

_Documentation can be found [here](https://taquito.io/docs/next/sapling)_
_TypeDoc style documentation is available on-line [here](https://taquito.io/typedoc/modules/_taquito_sapling.html)_

## General Information

Sapling is a protocol allowing to perform private transactions in a decentralized environment. This package allows to read from a sapling state (retrieve the balance and transaction history) and prepare sapling transactions.

## Install

Install the package as follows

```
npm install @taquito/sapling
```
## Usage

**Retrieve a balance in the Sapling shielded set**

The returned balance is in mutez.

```ts
import { TezosToolkit, RpcReadAdapter } from '@taquito/taquito';
import { SaplingToolkit, InMemorySpendingKey } from '@taquito/sapling';

const tezos = new TezosToolkit('https://shadownet.tezos.ecadinfra.com/');

const saplingContract = await tezos.contract.at('KT1UYwMR6Q6LZnwQEi77DSBrAjKT1tEJb245');

const inMemorySpendingKey = await InMemorySpendingKey.fromMnemonic('YOUR_MNEMONIC');

const readProvider = new RpcReadAdapter(tezos.rpc);

const saplingToolkit = new SaplingToolkit(
    { saplingSigner: inMemorySpendingKey },
    { contractAddress: saplingContract.address, memoSize: 8 },
    readProvider
)

const txViewer = await saplingToolkit.getSaplingTransactionViewer();
const initialBalance = await txViewer.getBalance();
```

**Prepare a shielded transaction**

A shielded transaction allows sending tokens from a Tezos account (tz1, tz2, tz3) to a Sapling address (zet).

```ts
import { TezosToolkit, RpcReadAdapter } from '@taquito/taquito';
import { SaplingToolkit, InMemorySpendingKey } from '@taquito/sapling';

const tezos = new TezosToolkit('https://shadownet.tezos.ecadinfra.com/');
// set up your signer on the TezosToolkit as usual
const saplingContract = await tezos.contract.at('KT1UYwMR6Q6LZnwQEi77DSBrAjKT1tEJb245');

const inMemorySpendingKey = await InMemorySpendingKey.fromMnemonic('YOUR_MNEMONIC');

const readProvider = new RpcReadAdapter(tezos.rpc);

const saplingToolkit = new SaplingToolkit(
    { saplingSigner: inMemorySpendingKey },
    { contractAddress: saplingContract.address, memoSize: 8 },
    readProvider
)

// Fetch a payment address (zet)
const inMemoryViewingKey = await inMemorySpendingKey.getSaplingViewingKeyProvider();
const paymentAddress = (await inMemoryViewingKey.getAddress()).address;

// prepare the shielded transaction
const shieldedTx = await saplingToolkit.prepareShieldedTransaction([{
    to: paymentAddress,
    amount: 3,
    memo: 'test',
    mutez: false // set to false by default
}])

// Inject the sapling transaction using the ContractAbstraction
// The amount MUST be specified in the send method to transfer the 3 tez to the shielded set
const op = await saplingContract.methodsObject.default([shieldedTx]).send({ amount: 3 });
await op.confirmation();
```

Refer to the website documentation for further examples and information: https://taquito.io/docs/next/sapling

## Additional info

See the top-level project [https://github.com/ecadlabs/taquito](https://github.com/ecadlabs/taquito) for details on reporting issues, contributing and versioning.

## Disclaimer

THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## Output order

The default transaction builder preserves recipient order and appends private change.
Omitting `outputOrder` preserves this behavior.
Explicit `'preserve'` has the same behavior and requests no extra randomness for ordering.

```typescript
import { InMemorySpendingKey, SaplingToolkit } from '@taquito/sapling';
import { RpcClient } from '@taquito/rpc';
import { RpcReadAdapter } from '@taquito/taquito';

const saplingSigner = await InMemorySpendingKey.fromMnemonic(mnemonic);
const readProvider = new RpcReadAdapter(new RpcClient(rpcUrl));

// Existing callers preserve output order.
const preserved = new SaplingToolkit(
	{ saplingSigner },
	{ contractAddress, memoSize: 8 },
	readProvider
);

// Opt in to randomized output order.
const randomized = new SaplingToolkit(
	{ saplingSigner },
	{ contractAddress, memoSize: 8, outputOrder: 'randomized' },
	readProvider
);
```

`'randomized'` shuffles complete output descriptions before the binding signature.
The policy applies to shield operations and private transactions, including change.
Zero or one output requires no ordering randomness.
Randomization can retain the original order.

The builder uses `globalThis.crypto.getRandomValues` through its existing random-byte provider.
The shuffle uses Fisher-Yates with rejection sampling to avoid modulo bias.
A failure to obtain randomness rejects the transaction before creating the binding signature.
An unknown policy throws the exported `InvalidSaplingOutputOrderError` during default builder construction.
This error extends `ParameterValidationError` from `@taquito/core`.
Only an omitted option or `undefined` selects the default.

Output positions and the corresponding history positions can change in randomized mode.
Applications must not identify recipients or change from output position.
The shuffle keeps each proof and ciphertext with its original output description.
It does not change amounts, memos, recipients, inputs, or bound withdrawal data.

A custom `saplingTxBuilder` passed to `SaplingToolkit` replaces the default builder.
That custom builder is responsible for policy validation, secure randomness, output ordering, and signing.
The toolkit does not shuffle the custom builder's result.

Randomized output order removes the default builder's deterministic last-position change rule.
It does not hide output counts or public deposits and withdrawals.
Amounts, timing, application behavior, and other evidence can still identify outputs or users.
This option does not provide a proof of anonymity.

### Check the public constructor types

From the repository root, run:

```sh
npm run typecheck:tests
npm run build
npm run test:consumers
```

The CI jobs on Node 22, 24 and 26 check the same constructor fixture in
`test-fixtures/consumers/sapling-output-order.types.ts`.
The root type-check resolves the public package through source aliases.
The installed-consumer runner packs Sapling and its workspace dependencies, then
checks the emitted declarations outside the workspace under strict NodeNext CJS,
NodeNext ESM and bundler resolution. The fixtures consume native byte arrays without opting into Node globals.

The fixture covers the existing constructor, both output-order policies and an
unknown policy that TypeScript must reject. The runtime fixture also checks
constructor creation and error identity through CommonJS and native ESM.
Neither fixture generates proofs or submits transactions.

## Custom bound data

`SaplingTransactionBuilder` and `SaplingForger` are exported from `@taquito/sapling`
for contracts whose bound data differs from the shielded-tez contract:

```ts
import { SaplingTransactionBuilder, SaplingForger } from '@taquito/sapling';
import { hex2buf } from '@taquito/utils';
import { packDataBytes } from '@taquito/michel-codec';

const forger = new SaplingForger();
const builder = new SaplingTransactionBuilder(keys, forger, contractDetails, readProvider);
const boundData = hex2buf(packDataBytes({ string: recipient }, { prim: 'address' }).bytes);
const description = await builder.createSaplingTx([], amount, boundData, chosenInputs);
const transaction = forger.forgeSaplingTransaction({ ...description, root, boundData });
```

The application supplies keys, contract details, a read provider, an amount in base
units as a `BigNumber` or another `BigNumber.Value`, the current root and
selected spendable inputs. It must
encode bound data according to its contract and pass the same bytes to the builder
and forger. `createShieldedTx` also accepts bound data as its third argument.
`SaplingToolkit.prepareUnshieldedTransaction` retains its existing recipient-key-hash
encoding. The low-level builder leaves recipient validation and input selection to
the application.
